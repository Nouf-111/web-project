<?php
session_start();
include "db.php";
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = mysqli_real_escape_string($conn, $_POST["login_email"]);
    $password = $_POST["login_password"];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {

        $user = mysqli_fetch_assoc($result);

        if (password_verify($password, $user["password"])) {

            $_SESSION["user_id"] = $user["id"];
            $_SESSION["name"] = $user["name"];

            // ✅ التعديل الصحيح هنا
            header("Location: index.html");
            exit();

        } else {
            $message = "كلمة المرور غير صحيحة";
        }

    } else {
        $message = "البريد الإلكتروني غير مسجل";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>تسجيل الدخول</title>
<link rel="stylesheet" href="StylePlay.css">
</head>

<body>

<div class="form-page">
    <h2>تسجيل الدخول</h2>

    <form method="POST" autocomplete="off">

        <input type="text" name="fake_user" style="display:none">
        <input type="password" name="fake_pass" style="display:none">

        <input 
            type="email" 
            name="login_email" 
            placeholder="البريد الإلكتروني" 
            required 
            autocomplete="off"
        >

        <input 
            type="password" 
            name="login_password" 
            placeholder="كلمة المرور" 
            required 
            autocomplete="off"
        >

        <button type="submit" class="btn-primary">تسجيل الدخول</button>
    </form>

    <p><?php echo $message; ?></p>
    <p>ليس لديك حساب؟ <a href="signup.php">إنشاء حساب</a></p>
</div>

</body>
</html>