<?php
include "db.php";
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = $_POST["password"];
    $confirm = $_POST["confirm"];

    if ($password != $confirm) {
        $message = "كلمة المرور غير متطابقة";
    } else {

        // التحقق من تكرار الإيميل
        $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

        if (mysqli_num_rows($check) > 0) {
            $message = "البريد الإلكتروني مستخدم مسبقاً";
        } else {

            $hashed = password_hash($password, PASSWORD_DEFAULT);

            $sql = "INSERT INTO users (name, email, password)
                    VALUES ('$name', '$email', '$hashed')";

            if (mysqli_query($conn, $sql)) {
                $message = "تم إنشاء الحساب بنجاح";
            } else {
                $message = "حدث خطأ";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>إنشاء حساب</title>
<link rel="stylesheet" href="StylePlay.css">
</head>
<body>

<div class="form-page">
    <h2>إنشاء حساب</h2>

    <form method="POST" autocomplete="off">
        <input type="text" name="name" placeholder="الاسم" required autocomplete="off">
        <input type="email" name="email" placeholder="البريد الإلكتروني" required autocomplete="off">
        <input type="password" name="password" placeholder="كلمة المرور" required autocomplete="new-password">
        <input type="password" name="confirm" placeholder="تأكيد كلمة المرور" required autocomplete="new-password">

        <button type="submit" class="btn-primary">إنشاء حساب</button>
    </form>

    <p><?php echo $message; ?></p>
    <p>لديك حساب؟ <a href="signin.php">تسجيل الدخول</a></p>
</div>

</body>
</html>