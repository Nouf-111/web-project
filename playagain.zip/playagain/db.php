<?php
$conn = mysqli_connect("localhost", "root", "", "playagain");

if (!$conn) {
    die("فشل الاتصال: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8");
?>